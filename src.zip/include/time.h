/* SPDX-License-Identifier: BSD-3-Clause */

#ifndef __TIME_H__
#define __TIME_H__ 1

#endif

#include <internal/types.h>
struct timespec {
    int64_t tv_sec;
    int64_t tv_nsec;
};
int nanosleep(const struct timespec *req, struct timespec *rem);
