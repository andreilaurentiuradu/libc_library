// SPDX-License-Identifier: BSD-3-Clause

#include <errno.h>
#include <internal/syscall.h>
#include <sys/stat.h>

int fstat(int fd, struct stat *st) {
    /* TODO: Implement fstat(). */
    int ans = syscall(5, fd, st);

    if (ans == -EBADF) {
        errno = -ans;
        return -1;
    }

    return ans;
}
