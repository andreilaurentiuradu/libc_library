// SPDX-License-Identifier: BSD-3-Clause

#include <errno.h>
#include <fcntl.h>
#include <internal/syscall.h>
#include <sys/stat.h>

int stat(const char *restrict path, struct stat *restrict buf) {
    /* TODO: Implement stat(). */
    int ans = syscall(4, path, buf);

    if (ans == -ENOENT || ans == -EBADF) {
        errno = -ans;
        return -1;
    }

    return ans;
}
